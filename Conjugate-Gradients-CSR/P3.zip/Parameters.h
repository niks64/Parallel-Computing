#pragma once
#include <iostream>
#define XDIM 256
#define YDIM 256
#define ZDIM 256
//#define DO_NOT_USE_MKL

constexpr int kMax = 1000;
constexpr float nuMax = 1e-3;


