#pragma once

#include "CSRMatrix.h"
#include "Parameters.h"

CSRMatrix BuildUpperTriangularLaplacianMatrix();

