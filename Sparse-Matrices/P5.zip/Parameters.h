#pragma once

#define XDIM 64
#define YDIM 64
#define ZDIM 64
#define K_NUM_RHS 100

constexpr int kMax = 1000;
constexpr float nuMax = 1e-3;
