#pragma once

#ifndef rMATRIX_SIZE_ONE
#define rMATRIX_SIZE_ONE 1024
#endif
#ifndef cMATRIX_SIZE_ONE
#define cMATRIX_SIZE_ONE 2048
#endif
#ifndef rMATRIX_SIZE_TWO
#define rMATRIX_SIZE_TWO 2048
#endif
#ifndef cMATRIX_SIZE_TWO
#define cMATRIX_SIZE_TWO 4096
#endif

#ifndef BLOCK_SIZE
#define BLOCK_SIZE 16
#endif
